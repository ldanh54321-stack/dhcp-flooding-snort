#!/bin/bash
# Startup script for snort container (dhcp-flooding-snort)
set -e

# Wait for eth0 interface to be up
for i in {1..10}; do
    if ip link show eth0 >/dev/null 2>&1; then
        break
    fi
    sleep 1
done

echo "[snort] Setting eth0 to promiscuous mode..."
ip link set eth0 promisc on || true

mkdir -p /etc/snort/rules /var/log/snort /home/ubuntu/rules
chown -R ubuntu:ubuntu /var/log/snort /home/ubuntu/rules

# Copy rules
cp /home/ubuntu/rules/dhcp_flooding.rules /etc/snort/rules/local.rules 2>/dev/null || \
cp "$(dirname "$0")/rules/dhcp_flooding.rules" /etc/snort/rules/local.rules 2>/dev/null || true
cp /etc/snort/rules/local.rules /home/ubuntu/rules/dhcp_flooding.rules 2>/dev/null || true

# Clean alert log
touch /var/log/snort/alert
chmod 666 /var/log/snort/alert

# Stop existing snort if any
pkill -9 snort 2>/dev/null || true

# Start Snort daemon on eth0
echo "[snort] Starting Snort NIDS daemon on eth0..."
snort -D -q -i eth0 -c /etc/snort/snort.conf -l /var/log/snort -A fast
sleep 1

if pgrep snort > /dev/null; then
    echo "[snort] Snort daemon running (PID $(pgrep snort)). Alert file: /var/log/snort/alert"
else
    echo "[snort] ERROR: Snort daemon failed to start. Check /var/log/snort/snort_test.log"
fi
