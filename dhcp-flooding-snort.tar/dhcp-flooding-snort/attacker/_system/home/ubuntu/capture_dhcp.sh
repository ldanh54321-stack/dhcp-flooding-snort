#!/bin/bash
OUTFILE="${1:-/root/dhcp_traffic.pcap}"
echo "[*] Capturing DHCP traffic on eth0. Output file: $OUTFILE"
echo "[*] Press Ctrl+C to finish capture."
tcpdump -n -i eth0 -w "$OUTFILE" port 67 or port 68
echo "[*] Capture completed: $OUTFILE"
