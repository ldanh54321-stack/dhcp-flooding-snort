#!/bin/bash
# Startup script for dhcp-server container (dhcp-flooding-snort)
set -e

mkdir -p /etc/dhcp /var/lib/dhcp /var/log
touch /var/lib/dhcp/dhcpd.leases
chmod 644 /var/lib/dhcp/dhcpd.leases

cat > /etc/dhcp/dhcpd.conf << 'CONF'
default-lease-time 60;
max-lease-time 120;
allow unknown-clients;
log-facility local7;

subnet 192.168.0.0 netmask 255.255.255.0 {
}

subnet 10.10.0.0 netmask 255.255.255.0 {
    range 10.10.0.100 10.10.0.200;
    option routers 10.10.0.1;
    option domain-name-servers 8.8.8.8;
    option domain-name "dhcp-snort.lab";
}
CONF

if [ -f /etc/default/isc-dhcp-server ]; then
    sed -i 's/^INTERFACESv4=.*/INTERFACESv4="eth0"/' /etc/default/isc-dhcp-server
else
    echo 'INTERFACESv4="eth0"' > /etc/default/isc-dhcp-server
fi

# Add static route to EXTERNAL network via relay
ip route add 10.10.0.0/24 via 192.168.0.1 2>/dev/null || true

# Start dhcpd
pkill -9 dhcpd 2>/dev/null || true
dhcpd -4 -f -d eth0 &>/var/log/dhcpd.log &
echo "[dhcp-server] ISC DHCP Server started on eth0 (PID $!)."
