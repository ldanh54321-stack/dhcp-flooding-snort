#!/bin/bash
echo "Pinging DHCP Relay (10.10.0.1):"
ping -c 3 -W 2 10.10.0.1 && echo "  [OK] Relay reachable" || echo "  [FAIL] Relay unreachable"
echo ""
echo "Pinging Snort IDS (10.10.0.5):"
ping -c 2 -W 2 10.10.0.5 && echo "  [OK] Snort reachable" || echo "  [FAIL] Snort unreachable"
