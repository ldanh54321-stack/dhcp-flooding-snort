#!/bin/bash
echo "[*] Monitoring DHCP traffic across all relay interfaces (eth0, eth1)..."
echo "[*] Press Ctrl+C to stop."
tcpdump -n -i any port 67 or port 68
