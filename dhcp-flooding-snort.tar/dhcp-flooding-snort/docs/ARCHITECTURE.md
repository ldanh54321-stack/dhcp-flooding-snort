# Architecture & Technical Design – dhcp-flooding-snort

## 1. Network Topology

```
+--------------------------------------------------------------------------+
|                             EXTERNAL NETWORK                             |
|                             10.10.0.0/24 (GW: 10.10.0.1)                 |
|                                                                          |
|   +-------------------+    +-------------------+   +------------------+  |
|   |    kali           |    |   snort (NIDS)    |   |  ubuntu-client   |  |
|   |    10.10.0.10     |    |   10.10.0.5       |   |  DHCP Assigned   |  |
|   |  (Attacker:       |    | (Promiscuous      |   | (Legitimate      |  |
|   |   Yersinia/Scapy) |    |  Snort 2.9 IDS)   |   |  workstation)    |  |
|   +---------+---------+    +---------+---------+   +--------+---------+  |
|             |                        |                      |            |
+-------------+------------------------+----------------------+------------+
                                       |
                         eth1: 10.10.0.1 (EXTERNAL)
                     +---------------------------------+
                     |           dhcp-relay            |
                     |  (Linux Router + dhcrelay)      |
                     +---------------------------------+
                         eth0: 192.168.0.1 (INTERNAL)
                                       |
+--------------------------------------+-----------------------------------+
|                             INTERNAL NETWORK                             |
|                             192.168.0.0/24 (GW: 192.168.0.254)           |
|                                                                          |
|                     +---------------------------------+                  |
|                     |           dhcp-server           |                  |
|                     |           192.168.0.100         |                  |
|                     |        (ISC DHCP Server)        |                  |
|                     |  Pool: 10.10.0.100-10.10.0.200  |                  |
|                     +---------------------------------+                  |
+--------------------------------------------------------------------------+
```

## 2. Component Specifications

| Container | Base Image | IP Address | Interfaces | Key Software | Role |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `dhcp-server` | `labtainer.network2` | 192.168.0.100 | `eth0` | ISC DHCP Server (`dhcpd`) | Manages 10.10.0.0/24 lease pool |
| `dhcp-relay` | `labtainer.network2` | 192.168.0.1 / 10.10.0.1 | `eth0`, `eth1` | `isc-dhcp-relay`, `iptables` | Dual-homed router & DHCP relay |
| `snort` | `labtainer.network2` | 10.10.0.5 | `eth0` | Snort 2.9.7 GRE, libpcap | Promiscuous NIDS sensor & alerting |
| `kali` | `labtainer.network2` | 10.10.0.10 | `eth0` | `yersinia`, Scapy, `tcpdump` | Controlled DHCP flood simulation |
| `ubuntu-client`| `labtainer.network2` | DHCP (10.10.0.100+) | `eth0` | `isc-dhcp-client` (`dhclient`) | Normal client validating service |

## 3. pfSense Compatibility & Integration Analysis

### 3.1. Technical Limitation of pfSense in Labtainers
- **Kernel Dependency:** pfSense is based on **FreeBSD**, requiring a FreeBSD kernel.
- **Docker Architecture:** Docker containers share the host Linux kernel (Ubuntu 24.04). Therefore, pfSense cannot run natively as a lightweight container inside Docker/Labtainers without hardware virtualization (QEMU/KVM).
- Running nested virtualization within a VMware guest VM for pfSense introduces severe performance degradation, instability, and compatibility issues across student workstations.

### 3.2. Architecture Solution: Standalone Snort NIDS
- To fulfill the exact research and defense objectives (detecting DHCP Flooding, analyzing rule alerts, traffic inspection), a dedicated container `snort` is deployed.
- It runs the official Snort 2.9.7 engine on the EXTERNAL segment in **promiscuous mode**, providing genuine intrusion detection capabilities identical to Snort running as a package inside pfSense.
- All alerts are logged to `/var/log/snort/alert` with fast alert format, easily auditable by students.

### 3.3. Optional External pfSense Integration (Hybrid Lab)
For advanced setups where an external pfSense VM in VMware is required:
1. Create a Host-Only virtual network in VMware (e.g., `vmnet2`).
2. Attach pfSense LAN interface to `vmnet2`.
3. Create a bridge on the Ubuntu host connecting `vmnet2` to Docker network `EXTERNAL`.

## 4. Snort Rule Design & DHCP Detection Theory

### 4.1. Packet Structure (UDP port 68 -> port 67)
```
+--------------------------------------------------------------+
| UDP Header: Source Port 68, Destination Port 67              |
+--------------------------------------------------------------+
| BOOTP / DHCP Payload:                                        |
|   Byte 0:       op = 0x01 (BOOTREQUEST)                      |
|   Bytes 1-235:  htype, hlen, hops, xid, secs, flags, ciaddr...|
|   Bytes 236-239:Magic Cookie = 0x63, 0x82, 0x53, 0x63       |
|   Byte 240+:    DHCP Options (Tag, Length, Value)            |
|                 Option 53 (0x35), Len 0x01, Val 0x01 (DISC)  |
+--------------------------------------------------------------+
```

### 4.2. Rule Field Breakdown
```snort
alert udp any 68 -> any 67 (
    msg:"[ATTACK] DHCP Flooding - Excessive DHCP Discover Detected";
    content:"|01|"; depth:1;
    content:"|63 82 53 63|"; offset:236;
    content:"|35 01 01|"; distance:0;
    detection_filter: track by_src, count 10, seconds 5;
    classtype:attempted-dos;
    sid:1000001; rev:1;
)
```

1. `alert udp any 68 -> any 67`:
   Inspects UDP traffic originating from client port 68 destined for server/relay port 67.
2. `content:"|01|"; depth:1;`:
   Validates the first byte is `0x01` (BOOTREQUEST).
3. `content:"|63 82 53 63|"; offset:236;`:
   Matches the 4-byte DHCP Magic Cookie at fixed byte offset 236.
4. `content:"|35 01 01|"; distance:0;`:
   Matches Option 53 (0x35 = 53), length 1 (0x01), value 1 (0x01 = DHCPDISCOVER).
5. `detection_filter: track by_src, count 10, seconds 5;`:
   Crucial rate-limiting threshold. A legitimate host emits 1 to 3 Discovers during boot. If a single IP generates 10 or more Discovers within 5 seconds, it flags an attack.
6. `detection_filter: track by_dst, count 25, seconds 5;` (Rule SID 1000002):
   Tracks by broadcast destination. If an attacker uses tools like Yersinia with spoofed random source IPs and MACs, `track by_src` would evaluate each fake IP independently. Tracking by destination aggregates all Discovers flooding the segment, reliably detecting spoofed starvation attacks.
